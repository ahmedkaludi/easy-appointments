export default {
  BOX: 'box'
};
