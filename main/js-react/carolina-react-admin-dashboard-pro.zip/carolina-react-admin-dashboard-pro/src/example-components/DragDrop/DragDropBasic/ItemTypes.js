export default {
  CARD: 'card'
};
