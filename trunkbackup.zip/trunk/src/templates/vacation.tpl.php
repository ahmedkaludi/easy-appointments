<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-vacation" class="easy-appointments"></div>