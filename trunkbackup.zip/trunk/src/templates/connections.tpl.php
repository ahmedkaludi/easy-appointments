<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-connections" class="easy-appointments"></div>