<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-tools" class="easy-appointments"></div>