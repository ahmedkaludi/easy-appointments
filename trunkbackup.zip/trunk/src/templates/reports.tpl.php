<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-reports" class="easy-appointments"></div>