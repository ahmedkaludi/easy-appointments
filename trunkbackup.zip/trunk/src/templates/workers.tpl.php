<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-workers" class="easy-appointments"></div>