<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-locations" class="easy-appointments"></div>