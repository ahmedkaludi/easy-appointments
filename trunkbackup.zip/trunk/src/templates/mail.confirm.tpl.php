<?php
defined( 'ABSPATH' ) || exit;
?>
<div>
    <p><?php esc_html_e('Do you want to Confirm appointment?', 'easy-appointments');?></p>
    <form method="post">
        <input name="confirmed" type="hidden" value="true">
        <button class="button button-primary"><?php esc_html_e('Yes, I want to Confirm appointment.', 'easy-appointments');?></button>
    </form>
</div>