<?php
defined( 'ABSPATH' ) || exit;
?>
<div id="ea-admin-services" class="easy-appointments"></div>